
const http = require('http');

const server = http.createServer((req, res) => {

    res.writeHead(200, {
        'Content-Type': 'text/html'
    });

    if (req.url === '/' || req.url === '/home') {
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Home Page</title>
            </head>
            <body>
                <h1>Welcome to Home Page!</h1>
                <p>This is the Home page of Node.js server.</p>
            </body>
            </html>
        `);
    }

    else if (req.url === '/about') {
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>About Page</title>
            </head>
            <body>
                <h1>Welcome to About Page!</h1>
                <p>This is the About page of Node.js server.</p>
            </body>
            </html>
        `);
    }

    else {
        res.end(`
            <h1>Page Not Found</h1>
            <p>The requested page does not exist.</p>
        `);
    }

});

server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
